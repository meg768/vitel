/*

@name 
Testfråga

@description 
En besrivning
av frågan som kan vara lite längre än en rad. 


*/

SELECT * FROM players LIMIT 5;