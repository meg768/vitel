import React from 'react';
import Page from '../../components/page';
import Link from '../../components/ui/link';

let Component = () => {
	function Content() {
		return (
			<Page.Content>
				<Page.Title>Q&A</Page.Title>
				<Page.Container>
					<Title />
					<Queries />
				</Page.Container>
			</Page.Content>
		);
	}

	function Title() {
		return <div className='text-lg pt-4 pb-2'>Här är några frågor som kan vara intressanta att ställa till databasen. Det är inte säkert att de ger något vettigt svar...</div>;
	}

	function Queries() {
		return (
			<div>
				<Query title='Fråga 1' description='Visa de första 5 spelarna i databasen' sql='SELECT * FROM players LIMIT 5' />
				<Query title='Fråga 2' description='Visa de första 10 spelarna i databasen' sql='SELECT * FROM players LIMIT 10' />
			</div>
		);
	}

	function Query({ sql, title = null, description = '-', ...props }) {
		/*
        Just nu genereras en länk som skickar vidare sql-frågan till players-sidan, där den kan exekveras och visa resultatet. 
        Det ska till en ny sida /query som är mer anpassad för att visa generella SQL-frågor
        */
		return (
			<div className='text-xl  border-1 p-3 mt-3 mb-3 bg-primary-500/10 rounded-md hover:bg-primary-500/20'>
				<Link hover={false} query={{ sql, title }} to={`/players`} {...props}>
					<div>{title} </div>
					<div className={'text-sm! bg-transparent '}>{description}</div>
				</Link>
			</div>
		);
	}

	return (
		<>
			<Page id='qna-page'>
				<Page.Menu />
				<Content />
			</Page>
		</>
	);
};

export default Component;
